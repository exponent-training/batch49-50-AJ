package com;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.Entity.Employee;
import com.Repository.EmployeeRepository;

@SpringBootApplication
public class Sb7JpaApplication {

	@Autowired
	private static SessionFactory sf;

	public static void main(String[] args) {
		ConfigurableApplicationContext run = SpringApplication.run(Sb7JpaApplication.class, args);
		EmployeeRepository er = run.getBean(EmployeeRepository.class);

		Employee emp1 = new Employee();
		emp1.setEname("raj");
		emp1.setRole("SE");
		emp1.setSalary(55000.0);
		emp1.setEaddress("Pune");

		Employee emp2 = new Employee();
		emp2.setEname("ram");
		emp2.setRole("TSE");
		emp2.setSalary(45000.0);
		emp2.setEaddress("Pune");

		Employee emp3 = new Employee();
		emp3.setEname("ravi");
		emp3.setRole("PD");
		emp3.setSalary(10000.0);
		emp3.setEaddress("Mumbai");

		Employee emp4 = new Employee();
		emp4.setEname("Karan");
		emp4.setRole("JD");
		emp4.setSalary(98000.0);
		emp4.setEaddress("Mumbai");

//		er.saveAll(Arrays.asList(emp1, emp2, emp3, emp4));

//		System.out.println("Data inserted");

//		Iterable<Employee> findAll = er.findAll();
//		for (Employee employee : findAll) {
//			System.out.println(employee);
//		}

//		Iterable<Employee> only123 = er.findAllById(Arrays.asList(1, 2));
//		for (Employee employee : only123) {
//			System.out.println(employee);
//		}

//		Employee emp = er.findById(2).get();

//		System.out.println(emp);

//		List<Employee> content = er.findAll(PageRequest.of(1, 24)).getContent();
//		for (Employee employee : content) {
//			System.out.println(employee);
//		}

//		List<Employee> sortedEmployees = er.findAll(Sort.by("salary").descending());
//		for (Employee employee : sortedEmployees) {
//			System.out.println(employee);
//		}

		List<Employee> allSE = er.findByRole("SE");
		for (Employee employee : allSE) {
			System.out.println(employee);
		}

		System.out.println("----------------------------");

		List<Employee> allLTFifty = er.findBySalaryLessThan(50000.0);
		for (Employee employee : allLTFifty) {
			System.out.println(employee);
		}
		System.out.println("---------------------------------------");

		List<Employee> employees = er.getallEmployees();
		for (Employee employee : employees) {
			System.out.println(employee);
		}

		System.out.println("--------------------------------------------------------");

		List<Employee> Remployees = er.rstartEmployee();
		for (Employee employee : Remployees) {
			System.out.println(employee);
		}

		System.out.println("--------------------------------------------------------");

		er.updateNameOnTheBasisID("pawan", 2);

	}

}
