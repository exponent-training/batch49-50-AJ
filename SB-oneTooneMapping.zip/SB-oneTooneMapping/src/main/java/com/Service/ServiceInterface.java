package com.Service;

import java.util.List;

import com.Entity.Person;

public interface ServiceInterface {

	int addPersonWithAdharInService(Person person);

	List<Person> getPersonWithAdharinService();

	Person getSinglePersonusingID(int pid);

}
