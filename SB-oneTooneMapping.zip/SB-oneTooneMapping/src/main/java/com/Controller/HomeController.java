package com.Controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.DTO.PeronNameAndAdharNo;
import com.Entity.Person;
import com.Service.ServiceInterface;

@RestController
public class HomeController {

	@Autowired
	private ServiceInterface si;

	@PostMapping("/addpersonAdhar")
	public ResponseEntity<?> addPersonWithAdhar(@Valid @RequestBody Person person) {
		System.out.println(person);
		int result = si.addPersonWithAdharInService(person);

		if (result == 1) {
			return new ResponseEntity("Person added", HttpStatus.OK);
		} else {
			return new ResponseEntity("Person is not valid", HttpStatus.BAD_REQUEST);
		}

	}

	/*
	 * @GetMapping("/getPersonWithAdhar") public ResponseEntity<?>
	 * getPersonWithAdhar() { List<Person> allPerson =
	 * si.getPersonWithAdharinService();
	 * 
	 * List<PeronNameAndAdharNo> dtoList = new ArrayList<PeronNameAndAdharNo>();
	 * 
	 * for (Person person : allPerson) { PeronNameAndAdharNo dto = new
	 * PeronNameAndAdharNo(); dto.setAdharNo(person.getAdhar().getAdharNo());
	 * dto.setPname(person.getPname());
	 * 
	 * dtoList.add(dto);
	 * 
	 * }
	 * 
	 * return new ResponseEntity(dtoList, HttpStatus.OK); }
	 */

	@GetMapping("/getSinglePerson/{id}")
	public ResponseEntity<?> getSinglePerson(@PathVariable("id") int pid) {
		
		Person sperson = si.getSinglePersonusingID(pid);
		
		PeronNameAndAdharNo result = PeronNameAndAdharNo.builder().adharNo(sperson.getAdhar().getAdharNo()).pname(sperson.getPname()).build();
		
		
		
		return new ResponseEntity(result, HttpStatus.OK);
	}

}
