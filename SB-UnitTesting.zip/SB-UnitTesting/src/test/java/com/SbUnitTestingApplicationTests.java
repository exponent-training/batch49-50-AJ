package com;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbUnitTestingApplicationTests {

	public static CalulatorTesting cal = null;

	@BeforeAll
	public static void init() {
		cal = new CalulatorTesting();
	}

	@AfterAll
	public static void destroy() {
		cal = null;
	}

	@Test
	@ParameterizedTest
	@ValueSource(ints = { 2, 3, 4, 5 })
	public void TestAdd(int a) {
//		CalulatorTesting cal = new CalulatorTesting();
		int result = cal.Add(a, 5);
		assertEquals(10, result);
	}

	@Test
	public void TestMulti() {
//		CalulatorTesting cal = new CalulatorTesting();
		int result = cal.Mult(5, 5);
		assertEquals(25, result);
	}

}
