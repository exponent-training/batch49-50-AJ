package com.Service;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Controller.UserController;
import com.Entity.User;
import com.Repository.UserRepository;

@Service
public class UserServiceIMPl implements UserService {

	Logger logger = LoggerFactory.getLogger(UserServiceIMPl.class);

	@Autowired
	private UserRepository ur;

	@Override
	public int addUserInService(User user) {

		if (user != null) {

			user.setDate(new Date());

			ur.save(user);
			logger.info("User added");
		} else {
			logger.warn("User should not be null");
			return 1;
		}

		return 0;

	}

	@Override
	public List<User> getUserFromService() {

		List<User> listUser = ur.findAll();

		return listUser;
	}

	@Override
	public int updateUserInService(User user) {

		if (user != null) {
			ur.save(user);
			logger.info("User Updated");
		} else {
			logger.warn("User should not be null");
			return 1;
		}

		return 0;

	}

	@Override
	public int deleteUserInService(int id) {

		User user = ur.findById(id).get();

		if (user != null) {
			ur.delete(user);
			logger.info("User Deleted");
		} else {
			logger.warn("User should not be null");
			return 1;
		}

		return 0;
	}

}
