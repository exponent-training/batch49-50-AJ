package com;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.endpoint.annotation.DeleteOperation;
import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.boot.actuate.endpoint.annotation.WriteOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Endpoint(id = "cendpoint")
public class CustomeEndpoint {

	@Value(value = "${myapplication}")
	private String valueFromAPF;

	@ReadOperation
	public String getEndpoint() {

		return "Welcome to customeEndpoint - my status is okay ";
	}

}
