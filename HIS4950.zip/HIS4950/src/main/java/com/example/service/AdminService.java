package com.example.service;

public interface AdminService {

	void assignRolesInService(String email, String roleName);

}
