package com.ThirdPartyAPICall;

import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class RestTemplateFirstExample {

	@GetMapping("/getDetailsFromAPI")
	public ResponseEntity<?> getCallFromAPI() {

//		1. hardcode the url.

		String url = "https://jsonplaceholder.typicode.com/posts";

//       2. create resttemplate object.

		RestTemplate rt = new RestTemplate();
		

//		3. create the call. (GET,POST,DELETE,PUT).

		ResponseEntity<String> result = rt.getForEntity(url, String.class);

//		4.take data from respective method.

		String body = result.getBody();

//		String body = rt.getForObject(url, String.class);

		return new ResponseEntity(body, HttpStatus.OK);

	}

}
