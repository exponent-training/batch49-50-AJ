package com.DTO;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PeronNameAndAdharNo {

	private String pname;

	private String adharNo;
}
