package com;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.Controller.WelcomeController;
import com.Service.WelcomeService;

@WebMvcTest(controllers = WelcomeController.class)
public class WelcomeControllerTest {

//	It is used to send httprequest to RestApi.
	@Autowired
	private MockMvc mockmvc;

	@MockBean
	private WelcomeService ws;
	
	// @injectbean micronaut

	

	@Test
	public void TestGetMsgMethod() throws Exception {

		when(ws.getMsgInService()).thenReturn("Service Call");

//		1. Generating Mock Request using MockMvcRequestBuilders.
		MockHttpServletRequestBuilder builder = MockMvcRequestBuilders.get("/welcome");

//		2. performing Request on RestAPI and getting response using MockMvc. 
		MockHttpServletResponse response = mockmvc.perform(builder).andReturn().getResponse();

//		3. getting status code from response.
		int status = response.getStatus();

//		response.getContentAsString();

//		4. checking actual response with expected.
		assertEquals(201, status);
	}
}
