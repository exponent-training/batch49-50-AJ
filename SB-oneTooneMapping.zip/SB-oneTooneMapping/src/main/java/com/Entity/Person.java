package com.Entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import org.springframework.validation.annotation.Validated;

import lombok.Builder;
import lombok.Data;

@Entity
@Data
@Validated
@Builder
public class Person {

	Person() {

	}

	public Person(int pid, @NotBlank(message = "This field should not blank") String pname,
			@Size(max = 100, message = "This fields size should be less than 100") String paddress,
			@Email(message = "Email is not valid") String pemail, Adhar adhar) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.paddress = paddress;
		this.pemail = pemail;
		this.adhar = adhar;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int pid;

	@NotBlank(message = "This field should not blank")
	private String pname;

	@Size(max = 100, message = "This fields size should be less than 100")
	private String paddress;

	@Email(message = "Email is not valid")
	private String pemail;

	@OneToOne(cascade = CascadeType.ALL)
	private Adhar adhar;

}
