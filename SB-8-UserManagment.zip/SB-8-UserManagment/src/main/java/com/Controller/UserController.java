package com.Controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Entity.User;
import com.Service.UserService;

@RestController
@RequestMapping("/exponent")
public class UserController {

	@Autowired
	private UserService us;

	Logger logger = LoggerFactory.getLogger(UserController.class);

	@PostMapping("/adduser")
	public ResponseEntity<?> AddUser(@RequestBody User user) {
		logger.info("I am in Controller " + user);

		int result = us.addUserInService(user);

		if (result == 0) {
			return new ResponseEntity("User Added Sucessfully", HttpStatus.OK);
		} else {
			return new ResponseEntity("User is null", HttpStatus.NOT_ACCEPTABLE);
		}

	}

}
