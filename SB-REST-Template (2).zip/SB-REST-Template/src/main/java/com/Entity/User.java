package com.Entity;

import java.util.Date;

import lombok.Data;

//@Entity
@Data
public class User {

//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int uid;

	private String uname;

	private String uemail;

	private String upassword;

	private String uaddress;

	private String gender;

//	@Temporal(TemporalType.DATE)
	private Date date;

}
