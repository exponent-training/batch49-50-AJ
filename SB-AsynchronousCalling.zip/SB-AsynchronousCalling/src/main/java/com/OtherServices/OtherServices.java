package com.OtherServices;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class OtherServices {

	@Async("asycnTaskExecution")
	public void Notification() throws InterruptedException {
		Thread.sleep(4000);
		System.out.println("Notification started");
	}

	@Async("asycnTaskExecution")
	public void Invoice() throws InterruptedException {
		Thread.sleep(4000);
		System.out.println("Invoice Generated");
	}

	@Async("asycnTaskExecution")
	public void packaging() throws InterruptedException {
		Thread.sleep(4000);
		System.out.println("packaging started");

	}

	@Async("asycnTaskExecution")
	public void shipping() throws InterruptedException {
		Thread.sleep(4000);
		System.out.println("shipping started");

	}

}
