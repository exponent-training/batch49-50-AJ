package com;

public class CalulatorTesting {

	public int Add(int a, int b) {
		return a + b;
	}

	public int Mult(int a, int b) {
		return a * b;
	}
}
