package com.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.OrderService.OserderService;
import com.OtherServices.OtherServices;

@RestController
public class LogisticController {

	@Autowired
	public OserderService os;

	@Autowired
	public OtherServices others;

	@GetMapping("/placeOrder")
	public void DoEcommerce() {
		try {

			os.doOrder();
			others.Notification();
			others.Invoice();
			others.packaging();
			others.shipping();

		} catch (Exception e) {
			System.out.println(e);
		}

	}
}
