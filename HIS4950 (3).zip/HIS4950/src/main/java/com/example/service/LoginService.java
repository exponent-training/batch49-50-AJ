package com.example.service;

import com.example.DTO.LoginDTO;
import com.example.Entity.Login;

public interface LoginService {

	LoginDTO loginUserInService(Login login);

}
