package com.example.service;

import com.example.DTO.ResponseDTO;
import com.example.Entity.Login;
import com.example.Entity.User;

public interface UserService {

	public ResponseDTO registerUserinService(Login login);

}
