package com.GlobalExceptionHandling;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandling {

	@ExceptionHandler(NullPointerException.class)
	public ResponseEntity<?> AllNullHandling() {

		return new ResponseEntity("Nullpointer occures check you apis", HttpStatus.OK);
	}

}
