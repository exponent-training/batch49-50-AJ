package com.DTOS;

import lombok.Data;

@Data
public class UserDTO {

	private String uname;

	private String uemail;

	private String uaddress;

	private String gender;

}
