package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbOneTooneMappingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbOneTooneMappingApplication.class, args);
	}

}
