package com.example.service;

import com.example.Entity.Roles;

public interface RoleService {

	void addRolesInService(Roles roles);

}
