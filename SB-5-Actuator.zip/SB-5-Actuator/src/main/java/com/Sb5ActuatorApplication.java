package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sb5ActuatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sb5ActuatorApplication.class, args);
	}

}
