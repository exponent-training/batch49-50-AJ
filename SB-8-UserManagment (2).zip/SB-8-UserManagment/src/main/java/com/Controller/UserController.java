package com.Controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.DTOS.UserDTO;
import com.Entity.User;
import com.Service.UserService;

@RestController
@RequestMapping("/exponent")
public class UserController {

	@Autowired
	private UserService us;

	Logger logger = LoggerFactory.getLogger(UserController.class);

	@PostMapping("/adduser")
	public ResponseEntity<?> AddUser(@RequestBody User user) {
		logger.info("I am in Controller " + user);

		int result = us.addUserInService(user);

		if (result == 0) {
			return new ResponseEntity("User Added Sucessfully", HttpStatus.OK);
		} else {
			return new ResponseEntity("User is null", HttpStatus.NOT_ACCEPTABLE);
		}

	}

	@GetMapping("/getUsers")
	public ResponseEntity<?> GetUserDetails() {

		List<UserDTO> udtoList = new ArrayList<UserDTO>();

		List<User> userList = us.getUserFromService();

		for (User user : userList) {

			UserDTO udto = new UserDTO();

			udto.setUname(user.getUname());
			udto.setUemail(user.getUemail());
			udto.setGender(user.getGender());
			udto.setUaddress(user.getUaddress());

			udtoList.add(udto);
		}

		logger.info("UserDTO Data :- " + udtoList);

		return new ResponseEntity(udtoList, HttpStatus.OK);

	}

	// single ID user Get. -> return only Useremail , gender.

	@PutMapping("/updateUser")
	public ResponseEntity<?> updateRespectedUserUsingUID(@RequestBody User user) {

		int result = us.updateUserInService(user);

		if (result == 0) {
			return new ResponseEntity("User Updated Sucessfully", HttpStatus.OK);
		} else {
			return new ResponseEntity("User is null", HttpStatus.NOT_ACCEPTABLE);
		}

	}

	// update User on the basis of User Email.

	@DeleteMapping("/deleteUser")
	public ResponseEntity<?> deleteUserOnTheBasisOfID(@RequestParam("uid") int id) {

		int result = us.deleteUserInService(id);

		if (result == 0) {
			return new ResponseEntity("User Deleted Sucessfully", HttpStatus.OK);
		} else {
			return new ResponseEntity("User is null", HttpStatus.NOT_ACCEPTABLE);
		}

	}

	@PostMapping("/dummycall")
	public ResponseEntity<?> DummyCall() {

		String str = null;

		System.out.println(str.toLowerCase());

		System.out.println("line1");
		System.out.println("line2");

		return new ResponseEntity("code working fine", HttpStatus.OK);

	}

	
}
