package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sb5SpringProfilingApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sb5SpringProfilingApplication.class, args);
	}

}
