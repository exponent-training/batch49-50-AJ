package com.example.DTO;

import lombok.Data;

@Data
public class ResponseDTO {

	private String msg;

}
