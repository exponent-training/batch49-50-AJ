package com.Repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.Entity.Employee;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

	public List<Employee> findByRole(String role);

	public List<Employee> findBySalaryLessThan(double salary);

//	@Query(value = "from Employee")
//	public List<Employee> getallEmployees();

	@Query(value = "select * from employee", nativeQuery = true)
	public List<Employee> getallEmployees();

	@Query(value = "select * from employee where ename like 'r%'", nativeQuery = true)
	public List<Employee> rstartEmployee();

	@Modifying
	@Transactional
	@Query(value = "update Employee set ename=:name where eid=:id")
	public void updateNameOnTheBasisID(String name, int id);

//	all employees get on the basis of salary (desc).

}
