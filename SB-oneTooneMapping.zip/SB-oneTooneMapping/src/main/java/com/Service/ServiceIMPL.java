package com.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Entity.Person;
import com.Repository.PersonRepo;

@Service
public class ServiceIMPL implements ServiceInterface {

	@Autowired
	private PersonRepo pr;

	@Override
	public int addPersonWithAdharInService(Person person) {

		if (person != null) {
			pr.save(person);

			return 1;

		} else {
			return 0;
		}

	}

	@Override
	public List<Person> getPersonWithAdharinService() {

		return pr.findAll();
	}

	@Override
	public Person getSinglePersonusingID(int pid) {

		return pr.findById(pid).get();
	}

}
