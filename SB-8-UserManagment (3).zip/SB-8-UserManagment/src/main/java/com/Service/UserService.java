package com.Service;

import java.util.List;

import com.Entity.User;

public interface UserService {

	public int addUserInService(User user);

	public List<User> getUserFromService();

	public int updateUserInService(User user);

	public int deleteUserInService(int id);

}
