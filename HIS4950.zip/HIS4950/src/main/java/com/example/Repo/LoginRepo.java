package com.example.Repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Entity.Login;

@Repository
public interface LoginRepo extends JpaRepository<Login, Integer> {

	
	public Login findByEmail(String email);
	
	public Login findByEmailAndPassword(String email , String password);
}
