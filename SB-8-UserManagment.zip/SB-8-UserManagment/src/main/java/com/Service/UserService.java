package com.Service;

import com.Entity.User;

public interface UserService {

	public int addUserInService(User user);

}
